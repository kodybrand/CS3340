﻿Public Class Prog06

    Public Shared Sub Main()
        Application.Run(New FormAllClass)
    End Sub
End Class
